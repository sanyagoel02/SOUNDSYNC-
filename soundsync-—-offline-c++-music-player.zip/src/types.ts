export interface Track {
  id: number;
  title: string;
  artist: string;
  album: string;
  duration: string;
  seconds: number;
  rate: string;
  size: string;
  path: string;
  genre: string;
  mood?: string;
  rootFreq: number;
  scale: number[];
  bpm: number;
  rhythmStyle?: 'synthwave' | 'hiphop' | 'edm' | 'house' | 'lofi' | 'jazz' | 'rock' | 'rnb' | 'pop' | 'classical' | 'acoustic' | 'ambient';
  audioAvailable?: boolean;
  coverArt?: string;
  memoryAddress?: string;
  bitrate?: string;
  bufferChunk?: string;
  memoryOffset?: string;
  threadId?: string;
}

export interface PlaylistNode {
  nodeId: string;
  ptr: string;
  prevPtr: string | null;
  nextPtr: string | null;
  track: Track;
}

export type ViewTab = 'all' | 'home' | 'search' | 'playlist' | 'recent' | 'favorites' | 'focus' | 'synthwave';
export type InspectorTab = 'specs' | 'wave' | 'notes';
