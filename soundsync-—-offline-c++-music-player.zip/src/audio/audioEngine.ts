import { Track } from '../types';

class AudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private filter: BiquadFilterNode | null = null;
  private padOsc1: OscillatorNode | null = null;
  private padOsc2: OscillatorNode | null = null;
  private padGain: GainNode | null = null;
  private sequencerTimer: ReturnType<typeof setInterval> | null = null;
  private isPlaying: boolean = false;
  private currentVolume: number = 0.75;
  private isMuted: boolean = false;
  private eqFilters: BiquadFilterNode[] = [];
  private eqFrequencies = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

  public init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      return;
    }
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AudioCtx();

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.currentVolume, this.ctx.currentTime);

    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 64;
    this.analyser.smoothingTimeConstant = 0.8;

    this.filter = this.ctx.createBiquadFilter();
    this.filter.type = 'lowpass';
    this.filter.frequency.setValueAtTime(1800, this.ctx.currentTime);
    this.filter.Q.setValueAtTime(2.2, this.ctx.currentTime);

    // Create 10-band EQ chain
    let prevNode: AudioNode = this.filter;
    this.eqFilters = this.eqFrequencies.map((freq, i) => {
      const node = this.ctx!.createBiquadFilter();
      if (i === 0) {
        node.type = 'lowshelf';
      } else if (i === this.eqFrequencies.length - 1) {
        node.type = 'highshelf';
      } else {
        node.type = 'peaking';
      }
      node.frequency.setValueAtTime(freq, this.ctx!.currentTime);
      node.gain.setValueAtTime(0, this.ctx!.currentTime);
      prevNode.connect(node);
      prevNode = node;
      return node;
    });

    prevNode.connect(this.masterGain);
    this.masterGain.connect(this.analyser);
    this.analyser.connect(this.ctx.destination);
  }

  public canPlayTrack(track: Track): boolean {
    return track.audioAvailable !== false;
  }

  public playTrack(track: Track): boolean {
    if (!this.canPlayTrack(track)) {
      this.stopPlayback();
      return false;
    }

    this.init();
    if (!this.ctx || !this.filter) return false;
    this.stopPlayback();
    this.isPlaying = true;

    const now = this.ctx.currentTime;
    const style = track.rhythmStyle || 'synthwave';
    const baseFreq = track.rootFreq || 110;

    try {
      // 1. Atmosphere / Pad Bed
      this.padOsc1 = this.ctx.createOscillator();
      this.padOsc2 = this.ctx.createOscillator();
      this.padGain = this.ctx.createGain();

      if (style === 'rock') {
        this.padOsc1.type = 'sawtooth';
        this.padOsc2.type = 'sawtooth';
      } else if (style === 'hiphop' || style === 'rnb') {
        this.padOsc1.type = 'sine';
        this.padOsc2.type = 'triangle';
      } else if (style === 'classical' || style === 'acoustic') {
        this.padOsc1.type = 'sine';
        this.padOsc2.type = 'sine';
      } else if (style === 'edm' || style === 'house') {
        this.padOsc1.type = 'sawtooth';
        this.padOsc2.type = 'triangle';
      } else {
        this.padOsc1.type = 'triangle';
        this.padOsc2.type = 'sine';
      }

      this.padOsc1.frequency.setValueAtTime(baseFreq * 0.5, now);
      this.padOsc2.frequency.setValueAtTime(baseFreq * (style === 'rock' ? 1.5 : 1.0), now);

      this.padOsc1.detune.setValueAtTime(-5, now);
      this.padOsc2.detune.setValueAtTime(5, now);

      this.padGain.gain.setValueAtTime(0.001, now);
      this.padGain.gain.exponentialRampToValueAtTime(0.15, now + 0.8);

      this.padOsc1.connect(this.padGain);
      this.padOsc2.connect(this.padGain);
      this.padGain.connect(this.filter);

      this.padOsc1.start();
      this.padOsc2.start();
    } catch {
      // Ignore autoplay errors
    }

    // 2. Rhythmic sequencer with genre-specific drum beats & melodies
    const bpm = track.bpm || 110;
    const stepDuration = 60 / bpm / 4; // 16th note steps
    let step = 0;
    const scale = track.scale && track.scale.length > 0 ? track.scale : [0, 3, 5, 7, 10, 12];

    this.sequencerTimer = setInterval(() => {
      if (!this.isPlaying || !this.ctx || !this.filter) return;

      try {
        const t = this.ctx.currentTime;
        const step16 = step % 16;

        // Genre-Specific Drum Elements:
        if (style === 'edm' || style === 'house') {
          // 4-on-the-floor Kick Drum
          if (step16 % 4 === 0) {
            this.triggerKick(t, 140, 45, 0.22);
          }
          // Off-beat Hi-Hat
          if (step16 % 4 === 2) {
            this.triggerHiHat(t, 0.08);
          }
        } else if (style === 'hiphop') {
          // Boom-Bap / Trap 808 Kick
          if (step16 === 0 || step16 === 7 || step16 === 10) {
            this.triggerKick(t, 110, 36, 0.35);
          }
          // Snare on 4 and 12
          if (step16 === 4 || step16 === 12) {
            this.triggerSnare(t, 0.18);
          }
        } else if (style === 'rock') {
          // Driving Rock Kick
          if (step16 === 0 || step16 === 6 || step16 === 8) {
            this.triggerKick(t, 130, 50, 0.2);
          }
          // Heavy Snare on 4 and 12
          if (step16 === 4 || step16 === 12) {
            this.triggerSnare(t, 0.22);
          }
        } else if (style === 'pop') {
          if (step16 % 4 === 0) {
            this.triggerKick(t, 135, 48, 0.2);
          }
          if (step16 === 4 || step16 === 12) {
            this.triggerSnare(t, 0.15);
          }
        }

        // Melodic Notes / Chords:
        // Adjust note trigger frequency based on style
        const shouldPlayNote =
          style === 'ambient'
            ? step16 % 4 === 0
            : style === 'classical'
            ? step16 % 2 === 0
            : style === 'lofi'
            ? step16 % 2 === 0
            : step16 % 2 === 0 || step16 % 3 === 0;

        if (shouldPlayNote) {
          const semitone = scale[step % scale.length];
          const oct = (step % 16 > 7) ? 2 : (step % 8 > 3 ? 1.5 : 1);
          const noteFreq = baseFreq * Math.pow(2, semitone / 12) * oct;

          const osc = this.ctx.createOscillator();
          const noteGain = this.ctx.createGain();

          if (style === 'rock') {
            osc.type = 'sawtooth';
          } else if (style === 'jazz' || style === 'lofi') {
            osc.type = step % 4 === 0 ? 'sine' : 'triangle';
          } else if (style === 'acoustic' || style === 'classical') {
            osc.type = 'triangle';
          } else {
            osc.type = (step % 4 === 0) ? 'triangle' : 'sine';
          }

          osc.frequency.setValueAtTime(noteFreq, t);

          // Envelope
          const noteLen = stepDuration * (style === 'classical' || style === 'ambient' ? 1.8 : 0.85);
          noteGain.gain.setValueAtTime(0.001, t);
          noteGain.gain.linearRampToValueAtTime(0.12, t + 0.015);
          noteGain.gain.exponentialRampToValueAtTime(0.0001, t + noteLen);

          osc.connect(noteGain);
          noteGain.connect(this.filter);

          osc.start(t);
          osc.stop(t + noteLen);
        }

        // Filter sweeps on house / EDM / synthwave
        if ((style === 'edm' || style === 'synthwave') && step16 === 0 && this.filter) {
          this.filter.frequency.cancelScheduledValues(t);
          this.filter.frequency.setValueAtTime(800, t);
          this.filter.frequency.exponentialRampToValueAtTime(2600, t + stepDuration * 4);
          this.filter.frequency.exponentialRampToValueAtTime(1400, t + stepDuration * 8);
        }

        step = (step + 1) % 64;
      } catch {
        // Safe catch
      }
    }, Math.round(stepDuration * 1000));

    return true;
  }

  // Synthesizer Drum Helper: Kick
  private triggerKick(time: number, startFreq: number, endFreq: number, duration: number) {
    if (!this.ctx || !this.filter) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(startFreq, time);
      osc.frequency.exponentialRampToValueAtTime(endFreq, time + duration);

      gain.gain.setValueAtTime(0.25, time);
      gain.gain.exponentialRampToValueAtTime(0.0001, time + duration);

      osc.connect(gain);
      gain.connect(this.filter);

      osc.start(time);
      osc.stop(time + duration);
    } catch {}
  }

  // Synthesizer Drum Helper: Snare
  private triggerSnare(time: number, duration: number) {
    if (!this.ctx || !this.filter) return;
    try {
      // Noise burst for snare snap
      const bufferSize = Math.floor(this.ctx.sampleRate * duration);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const noiseFilter = this.ctx.createBiquadFilter();
      noiseFilter.type = 'highpass';
      noiseFilter.frequency.setValueAtTime(1000, time);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.12, time);
      gain.gain.exponentialRampToValueAtTime(0.0001, time + duration);

      noise.connect(noiseFilter);
      noiseFilter.connect(gain);
      gain.connect(this.filter);

      noise.start(time);
      noise.stop(time + duration);
    } catch {}
  }

  // Synthesizer Drum Helper: HiHat
  private triggerHiHat(time: number, duration: number) {
    if (!this.ctx || !this.filter) return;
    try {
      const bufferSize = Math.floor(this.ctx.sampleRate * duration);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const noiseFilter = this.ctx.createBiquadFilter();
      noiseFilter.type = 'highpass';
      noiseFilter.frequency.setValueAtTime(7000, time);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.06, time);
      gain.gain.exponentialRampToValueAtTime(0.0001, time + duration);

      noise.connect(noiseFilter);
      noiseFilter.connect(gain);
      gain.connect(this.filter);

      noise.start(time);
      noise.stop(time + duration);
    } catch {}
  }

  public stopPlayback() {
    this.isPlaying = false;
    if (this.sequencerTimer) {
      clearInterval(this.sequencerTimer);
      this.sequencerTimer = null;
    }
    if (this.padGain && this.ctx) {
      try {
        this.padGain.gain.cancelScheduledValues(this.ctx.currentTime);
        this.padGain.gain.linearRampToValueAtTime(0.0001, this.ctx.currentTime + 0.1);
      } catch {}
    }
    setTimeout(() => {
      if (this.padOsc1) {
        try {
          this.padOsc1.stop();
          this.padOsc1.disconnect();
        } catch {}
        this.padOsc1 = null;
      }
      if (this.padOsc2) {
        try {
          this.padOsc2.stop();
          this.padOsc2.disconnect();
        } catch {}
        this.padOsc2 = null;
      }
    }, 120);
  }

  public setVolume(volume: number) {
    this.currentVolume = Math.max(0, Math.min(1, volume));
    this.isMuted = false;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.currentVolume, this.ctx.currentTime);
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.currentVolume, this.ctx.currentTime);
    }
    return this.isMuted;
  }

  public getVolume(): number {
    return this.isMuted ? 0 : this.currentVolume;
  }

  public setEqBand(index: number, gainDb: number) {
    if (this.eqFilters[index] && this.ctx) {
      this.eqFilters[index].gain.setValueAtTime(gainDb, this.ctx.currentTime);
    }
  }

  public getByteFrequencyData(): Uint8Array {
    if (!this.analyser) {
      return new Uint8Array(32);
    }
    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(dataArray);
    return dataArray;
  }
}

export const audioEngine = new AudioEngine();
