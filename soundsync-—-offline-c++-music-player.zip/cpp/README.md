# SoundSync — C++ Core Audio Workstation & Algorithmic Music Engine

## 1. Project Overview

**SoundSync** is a dual-paradigm music workstation and playlist management application designed for college software engineering, Object-Oriented Programming (OOP), and Data Structures and Algorithms (DSA) coursework.

The project consists of:
1. **A Native C++ Implementation (`/cpp`)**: Fully compilable, standard C++17 architecture utilizing custom memory pointers, manual heap allocation, and classic data structures.
2. **A High-Performance Web Frontend (`/src`)**: Interactive React + TypeScript visual interface demonstrating the exact same 40-song catalog, doubly linked list node graph visualization, live Web Audio synthesis, and parametric equalizer.

---

## 2. File Organization & Architecture

```
/cpp/
├── Song.h              # Declaration of the Song entity (Encapsulation)
├── Song.cpp            # Definition of Song constructors, getters, and tabular display
├── MusicLibrary.h      # Declaration of the MusicLibrary catalog manager
├── MusicLibrary.cpp    # Vector storage, file loading (songs.txt), and linear search
├── Playlist.h          # Custom Doubly Linked List structure (PlaylistNode, Playlist)
├── Playlist.cpp        # Pointer manipulation: insertion, deletion, bidirectional jumps
├── MusicPlayer.h       # Audio state machine controller declaration
├── MusicPlayer.cpp     # Play/pause/stop transitions, track switching, and diagnostics
├── main.cpp            # Interactive CLI menu and automated DSA verification test suite
├── songs.txt           # Formatted database of 40 songs (ID|Title|Artist|Album|Path|Duration)
├── Makefile            # Build script for Make / GCC / Clang
├── CMakeLists.txt      # Cross-platform build script for CMake
└── README.md           # Technical documentation and OOP/DSA academic report
```

---

## 3. Object-Oriented Programming (OOP) Concepts Applied

### 3.1 Encapsulation (`Song.h`, `Song.cpp`)
- **Data Hiding**: All member variables (`id`, `title`, `artist`, `album`, `filePath`, `duration`) are declared `private`.
- **Interface Segregation**: Modification from outside the class is prevented; consumers interact solely through const-qualified getters (`getId()`, `getTitle()`, `getArtist()`, etc.).
- **Self-Contained Formatting**: `Song::display()` formats the track's metadata into fixed-width columns using `<iomanip>`.

### 3.2 Composition (`MusicLibrary.h`, `MusicLibrary.cpp`)
- **"Has-A" Relationship**: `MusicLibrary` owns a dynamic array (`std::vector<Song> songs`).
- When a `MusicLibrary` instance is constructed or destroyed, its internal song entries are managed as a unified unit.

### 3.3 RAII (Resource Acquisition Is Initialization) (`Playlist.h`, `Playlist.cpp`)
- **Manual Heap Management**: `Playlist` allocates nodes on the heap (`new PlaylistNode(song)`).
- **Leak Prevention**: The destructor `Playlist::~Playlist()` calls `clear()`, traversing the list and invoking `delete` on every node to guarantee zero memory leaks upon destruction.
- **Rule of Three / Deep Copy**: Implements both a copy constructor `Playlist(const Playlist& other)` and a copy assignment operator `operator=` to prevent dangling pointers from shallow copying.

### 3.4 Association & State Machine (`MusicPlayer.h`, `MusicPlayer.cpp`)
- **Association**: `MusicPlayer` holds a pointer to an active `Playlist*`, allowing the player to manipulate the active playlist without strictly owning its lifetime.
- **State Pattern**: Enforces state transitions via `PlayerState` enum (`STOPPED`, `PLAYING`, `PAUSED`), rejecting invalid operations (e.g., pausing an already stopped engine).

---

## 4. Data Structures & Algorithms (DSA) Applied

### 4.1 Doubly Linked List (`PlaylistNode`, `Playlist`)
Unlike a basic array where moving to the next or previous track requires index arithmetic that can invalidate on mid-list deletions:
- Each `PlaylistNode` contains:
  ```cpp
  struct PlaylistNode {
      Song song;
      PlaylistNode* prev; // Pointer to predecessor node
      PlaylistNode* next; // Pointer to successor node
  };
  ```
- **O(1) Tail Insertion**: Appending a new song to the playlist maintains `head` and `tail` pointers, allowing constant time insertion without reallocating arrays.
- **O(1) Bidirectional Navigation**:
  - `nextTrack()` executes `current = current->next;` in O(1) time.
  - `previousTrack()` executes `current = current->prev;` in O(1) time.
- **O(1) Deletion (Pointer Unlink)**: Once a node is located, adjusting `temp->prev->next = temp->next;` and `temp->next->prev = temp->prev;` removes the song in constant time.

### 4.2 Dynamic Array (`std::vector<Song>`)
- Used in `MusicLibrary` for continuous memory layout and cache locality.
- Provides amortized $O(1)$ song insertion and $O(1)$ random access retrieval.

### 4.3 Linear Search Algorithm
- Used in `MusicLibrary::searchByTitle` and `MusicLibrary::searchByArtist`.
- Operates in $O(n)$ time complexity, iterating through all 40 tracks and performing case-insensitive substring comparisons (`containsIgnoreCase`).

### 4.4 Complexity Summary Table

| Operation | Data Structure / Algorithm | Time Complexity | Space Complexity |
|---|---|---|---|
| Library Add Song | Dynamic Array (`std::vector`) | $O(1)$ amortized | $O(1)$ |
| Search by Title / Artist | Linear Search | $O(n)$ | $O(1)$ auxiliary |
| Lookup by Song ID | Linear Search | $O(n)$ | $O(1)$ auxiliary |
| Playlist Add Song | Doubly Linked List (Tail Insert) | $O(1)$ | $O(1)$ node alloc |
| Playlist Remove Song | DLL Search + Pointer Unlink | $O(n)$ search, $O(1)$ unlink | $O(1)$ |
| Next / Previous Track | DLL Pointer Hop (`prev`/`next`) | $O(1)$ | $O(1)$ |
| Playlist Destructor Cleanup | Full Traversal & Deallocation | $O(n)$ | $O(1)$ auxiliary |

---

## 5. Audio Playback: C++ Architecture & External Libraries

### 5.1 Standard ISO C++ Limitations
The standard C++ specification (ISO/IEC 14882) standardizes memory, containers, threads, and input/output streams (`<iostream>`, `<fstream>`). It **does not include hardware audio digital-to-analog converters (DAC) or audio mixer drivers**.

### 5.2 Real Native Audio Integration
In production native desktop C++ software, audio playback is achieved by linking against a hardware abstraction library:
- **miniaudio** (Recommended for C++): Single-header public domain audio playback and capture library (`#define MINIAUDIO_IMPLEMENTATION`).
- **SDL2 / SDL2_mixer**: Industry standard multimedia library with full PCM streaming and WAV/FLAC decoders.
- **PortAudio / libsoundio**: Low-latency cross-platform audio I/O libraries.

### 5.3 SoundSync's Audio Design
In `MusicPlayer.cpp`, SoundSync implements the complete control logic:
- Loading audio paths (e.g. `/assets/audio/midnight_pulse.flac`)
- Play/Pause/Resume/Stop state machine
- Buffer position management

When paired with the web frontend (`src/audio/audioEngine.ts`), SoundSync leverages the browser's hardware-accelerated **Web Audio API** to synthesize the exact frequencies, BPM, and harmonics defined in the catalog.

---

## 6. How to Compile and Run the C++ Application

### Option A: Using GCC / Clang directly (Recommended)
```bash
# Navigate to the cpp folder
cd cpp

# Compile with C++17 standard
g++ -std=c++17 -Wall -Wextra -O2 Song.cpp MusicLibrary.cpp Playlist.cpp MusicPlayer.cpp main.cpp -o soundsync

# Run the interactive console
./soundsync

# Or run the automated test suite
./soundsync --test
```

### Option B: Using Make
```bash
cd cpp
make
./soundsync

# Run verification tests:
make test

# Clean artifacts:
make clean
```

### Option C: Using CMake
```bash
cd cpp
cmake -B build
cmake --build build
./build/soundsync
```

### Option D: Windows (Visual Studio / MinGW)
- **MinGW**: `g++ -std=c++17 Song.cpp MusicLibrary.cpp Playlist.cpp MusicPlayer.cpp main.cpp -o soundsync.exe`
- **Visual Studio**: Open the folder as a CMake Project or add the `.h` and `.cpp` files to a Win32 Console Application project.

---

## 7. Automated Test Suite Output Verification

When launched with `./soundsync --test` or menu option `17`:
```
============================================================
     RUNNING SOUNDSYNC AUTOMATED OOP & DSA TEST SUITE      
============================================================
[Test 1] Validating Music Library capacity (Expected: 40 songs)... PASSED (40 songs)
[Test 2] Validating Song Encapsulation on Track ID 4... PASSED ("Violet Horizon" by Kaelen Brooks)
[Test 3] Doubly Linked List insertion (O(1) tail append)... PASSED (Count: 3)
[Test 4] Doubly Linked List bidirectional navigation (O(1))... PASSED (Node 1 -> Node 2 -> Node 3 <-> Node 2 <-> Node 1)
[Test 5] Doubly Linked List node deletion and relinking... PASSED (Node 2 removed, Node 1 linked directly to Node 3)
[Test 6] Linear Search algorithms (Title & Artist)... PASSED (Found Entropy Zero by Null Reference)
[Test 7] MusicPlayer state machine transitions... PASSED (STOPPED -> PLAYING -> PAUSED -> PLAYING -> STOPPED)
============================================================
   TEST RESULT: 7/7 TESTS PASSED SUCCESSFULLY   
============================================================
```
